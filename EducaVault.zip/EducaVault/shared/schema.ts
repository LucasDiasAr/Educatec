import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoleEnum = pgEnum('user_role', ['admin', 'teacher', 'digitizer', 'coordinator', 'secretary', 'assistant_secretary']);
export const activityStatusEnum = pgEnum('activity_status', ['pending', 'in_review', 'approved', 'rejected', 'printed']);
export const incidentTypeEnum = pgEnum('incident_type', ['health', 'behavior', 'academic', 'other']);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: userRoleEnum("role").notNull(),
  phone: text("phone"),
  specialty: text("specialty"),
  admissionDate: timestamp("admission_date"),
  status: text("status").default('active'),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  subject: text("subject").notNull(),
  description: text("description"),
  fileUrl: text("file_url"),
  fileName: text("file_name"),
  teacherId: varchar("teacher_id").references(() => users.id).notNull(),
  digitizerId: varchar("digitizer_id").references(() => users.id),
  coordinatorId: varchar("coordinator_id").references(() => users.id),
  status: activityStatusEnum("status").default('pending'),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const inventoryItems = pgTable("inventory_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  quantity: integer("quantity").notNull().default(0),
  minQuantity: integer("min_quantity").notNull().default(10),
  unit: text("unit").notNull(),
  price: text("price"),
  supplier: text("supplier"),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const calendarEvents = pgTable("calendar_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  location: text("location"),
  type: text("type").notNull(),
  assignedTo: varchar("assigned_to").references(() => users.id),
  completed: boolean("completed").default(false),
  priority: text("priority").default('medium'),
  createdBy: varchar("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const studentIncidents = pgTable("student_incidents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentName: text("student_name").notNull(),
  studentClass: text("student_class").notNull(),
  incidentType: incidentTypeEnum("incident_type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  actionTaken: text("action_taken"),
  reportedBy: varchar("reported_by").references(() => users.id).notNull(),
  resolved: boolean("resolved").default(false),
  severity: text("severity").default('low'),
  parentNotified: boolean("parent_notified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const userRelations = relations(users, ({ many }) => ({
  activitiesAsTeacher: many(activities, { relationName: "teacher" }),
  activitiesAsDigitizer: many(activities, { relationName: "digitizer" }),
  activitiesAsCoordinator: many(activities, { relationName: "coordinator" }),
  calendarEvents: many(calendarEvents, { relationName: "assignedTo" }),
  createdEvents: many(calendarEvents, { relationName: "createdBy" }),
  reportedIncidents: many(studentIncidents),
}));

export const activityRelations = relations(activities, ({ one }) => ({
  teacher: one(users, {
    fields: [activities.teacherId],
    references: [users.id],
    relationName: "teacher"
  }),
  digitizer: one(users, {
    fields: [activities.digitizerId],
    references: [users.id],
    relationName: "digitizer"
  }),
  coordinator: one(users, {
    fields: [activities.coordinatorId],
    references: [users.id],
    relationName: "coordinator"
  }),
}));

export const calendarEventRelations = relations(calendarEvents, ({ one }) => ({
  assignedUser: one(users, {
    fields: [calendarEvents.assignedTo],
    references: [users.id],
    relationName: "assignedTo"
  }),
  createdBy: one(users, {
    fields: [calendarEvents.createdBy],
    references: [users.id],
    relationName: "createdBy"
  }),
}));

export const studentIncidentRelations = relations(studentIncidents, ({ one }) => ({
  reportedBy: one(users, {
    fields: [studentIncidents.reportedBy],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCalendarEventSchema = createInsertSchema(calendarEvents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertStudentIncidentSchema = createInsertSchema(studentIncidents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;
export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertCalendarEvent = z.infer<typeof insertCalendarEventSchema>;
export type CalendarEvent = typeof calendarEvents.$inferSelect;
export type InsertStudentIncident = z.infer<typeof insertStudentIncidentSchema>;
export type StudentIncident = typeof studentIncidents.$inferSelect;
