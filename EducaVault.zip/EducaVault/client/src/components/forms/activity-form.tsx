import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertActivitySchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const activityFormSchema = insertActivitySchema.omit({
  teacherId: true,
  status: true,
  digitizerId: true,
  coordinatorId: true,
  fileUrl: true,
  fileName: true,
});

type ActivityFormData = z.infer<typeof activityFormSchema>;

interface ActivityFormProps {
  onClose: () => void;
}

export default function ActivityForm({ onClose }: ActivityFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const subjects = [
    "Matemática",
    "Português", 
    "História",
    "Geografia",
    "Ciências",
    "Educação Física",
    "Artes",
    "Inglês",
    "Química",
    "Física",
    "Biologia",
    "Literatura",
    "Filosofia",
    "Sociologia"
  ];

  const form = useForm<ActivityFormData>({
    resolver: zodResolver(activityFormSchema),
    defaultValues: {
      title: "",
      subject: "",
      description: "",
    },
  });

  const createActivityMutation = useMutation({
    mutationFn: async (activityData: ActivityFormData) => {
      const res = await apiRequest("POST", "/api/activities", {
        ...activityData,
        teacherId: user?.id,
        status: 'pending',
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Atividade enviada com sucesso",
      });
      onClose();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ActivityFormData) => {
    createActivityMutation.mutate(data);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title">Título da Atividade</Label>
        <Input
          id="title"
          data-testid="input-activity-title"
          {...form.register("title")}
          placeholder="Ex: Exercícios de Matemática - 5º Ano"
        />
        {form.formState.errors.title && (
          <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject">Matéria</Label>
        <Select onValueChange={(value) => form.setValue("subject", value)}>
          <SelectTrigger data-testid="select-activity-subject">
            <SelectValue placeholder="Selecione a matéria" />
          </SelectTrigger>
          <SelectContent>
            {subjects.map((subject) => (
              <SelectItem key={subject} value={subject}>
                {subject}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {form.formState.errors.subject && (
          <p className="text-sm text-destructive">{form.formState.errors.subject.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          data-testid="textarea-activity-description"
          {...form.register("description")}
          placeholder="Descreva o conteúdo da atividade, instruções especiais, etc."
          rows={4}
        />
        {form.formState.errors.description && (
          <p className="text-sm text-descriptive">{form.formState.errors.description.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="file">Arquivo da Atividade</Label>
        <Input
          id="file"
          data-testid="input-activity-file"
          type="file"
          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
          className="cursor-pointer"
        />
        <p className="text-xs text-gray-500">
          Formatos aceitos: PDF, DOC, DOCX, JPG, PNG (máx. 10MB)
        </p>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          data-testid="button-cancel-activity"
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={createActivityMutation.isPending}
          data-testid="button-save-activity"
        >
          {createActivityMutation.isPending ? "Enviando..." : "Enviar Atividade"}
        </Button>
      </div>
    </form>
  );
}
