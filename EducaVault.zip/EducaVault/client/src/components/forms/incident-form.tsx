import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertStudentIncidentSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const incidentFormSchema = insertStudentIncidentSchema.omit({
  reportedBy: true,
});

type IncidentFormData = z.infer<typeof incidentFormSchema>;

interface IncidentFormProps {
  onClose: () => void;
}

export default function IncidentForm({ onClose }: IncidentFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const incidentTypes = [
    { value: "health", label: "Saúde" },
    { value: "behavior", label: "Comportamento" },
    { value: "academic", label: "Acadêmico" },
    { value: "other", label: "Outros" },
  ];

  const severities = [
    { value: "low", label: "Baixa" },
    { value: "medium", label: "Média" },
    { value: "high", label: "Alta" },
  ];

  const form = useForm<IncidentFormData>({
    resolver: zodResolver(incidentFormSchema),
    defaultValues: {
      studentName: "",
      studentClass: "",
      incidentType: "other",
      title: "",
      description: "",
      actionTaken: "",
      resolved: false,
      severity: "low",
      parentNotified: false,
    },
  });

  const createIncidentMutation = useMutation({
    mutationFn: async (incidentData: IncidentFormData) => {
      const res = await apiRequest("POST", "/api/incidents", {
        ...incidentData,
        reportedBy: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      toast({
        title: "Sucesso",
        description: "Ocorrência registrada com sucesso",
      });
      onClose();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: IncidentFormData) => {
    createIncidentMutation.mutate(data);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="studentName">Nome do Estudante</Label>
          <Input
            id="studentName"
            data-testid="input-student-name"
            {...form.register("studentName")}
            placeholder="Digite o nome completo"
          />
          {form.formState.errors.studentName && (
            <p className="text-sm text-destructive">{form.formState.errors.studentName.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="studentClass">Turma</Label>
          <Input
            id="studentClass"
            data-testid="input-student-class"
            {...form.register("studentClass")}
            placeholder="Ex: 5º Ano A"
          />
          {form.formState.errors.studentClass && (
            <p className="text-sm text-destructive">{form.formState.errors.studentClass.message}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="incidentType">Tipo de Ocorrência</Label>
          <Select onValueChange={(value) => form.setValue("incidentType", value as any)} defaultValue="other">
            <SelectTrigger data-testid="select-incident-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {incidentTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.incidentType && (
            <p className="text-sm text-destructive">{form.formState.errors.incidentType.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="severity">Gravidade</Label>
          <Select onValueChange={(value) => form.setValue("severity", value)} defaultValue="low">
            <SelectTrigger data-testid="select-incident-severity">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {severities.map((severity) => (
                <SelectItem key={severity.value} value={severity.value}>
                  {severity.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title">Título da Ocorrência</Label>
        <Input
          id="title"
          data-testid="input-incident-title"
          {...form.register("title")}
          placeholder="Ex: Estudante dispensado com dor de cabeça"
        />
        {form.formState.errors.title && (
          <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição Detalhada</Label>
        <Textarea
          id="description"
          data-testid="textarea-incident-description"
          {...form.register("description")}
          placeholder="Descreva o que aconteceu, circunstâncias, sintomas, etc."
          rows={4}
        />
        {form.formState.errors.description && (
          <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="actionTaken">Ação Tomada (opcional)</Label>
        <Textarea
          id="actionTaken"
          data-testid="textarea-action-taken"
          {...form.register("actionTaken")}
          placeholder="Descreva as ações tomadas para resolver a situação"
          rows={3}
        />
      </div>

      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="parentNotified"
            data-testid="checkbox-parent-notified"
            checked={!!form.watch("parentNotified")}
            onCheckedChange={(checked) => form.setValue("parentNotified", !!checked)}
          />
          <Label htmlFor="parentNotified" className="text-sm">
            Pais/responsáveis foram notificados
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="resolved"
            data-testid="checkbox-resolved"
            checked={!!form.watch("resolved")}
            onCheckedChange={(checked) => form.setValue("resolved", !!checked)}
          />
          <Label htmlFor="resolved" className="text-sm">
            Ocorrência já foi resolvida
          </Label>
        </div>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          data-testid="button-cancel-incident"
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={createIncidentMutation.isPending}
          data-testid="button-save-incident"
        >
          {createIncidentMutation.isPending ? "Registrando..." : "Registrar Ocorrência"}
        </Button>
      </div>
    </form>
  );
}
