import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { insertCalendarEventSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const eventFormSchema = insertCalendarEventSchema.omit({
  createdBy: true,
});

type EventFormData = z.infer<typeof eventFormSchema>;

interface EventFormProps {
  onClose: () => void;
}

export default function EventForm({ onClose }: EventFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: users } = useQuery({
    queryKey: ["/api/users"],
  });

  const eventTypes = [
    { value: "meeting", label: "Reunião" },
    { value: "task", label: "Tarefa" },
    { value: "deadline", label: "Prazo" },
    { value: "event", label: "Evento" },
  ];

  const priorities = [
    { value: "low", label: "Baixa" },
    { value: "medium", label: "Média" },
    { value: "high", label: "Alta" },
  ];

  const form = useForm<EventFormData>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: "",
      description: "",
      startDate: new Date(),
      endDate: new Date(),
      location: "",
      type: "meeting",
      assignedTo: undefined,
      completed: false,
      priority: "medium",
    },
  });

  const createEventMutation = useMutation({
    mutationFn: async (eventData: EventFormData) => {
      const res = await apiRequest("POST", "/api/calendar/events", {
        ...eventData,
        createdBy: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Evento criado com sucesso",
      });
      onClose();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: EventFormData) => {
    createEventMutation.mutate(data);
  };

  // Format datetime for input
  const formatDateTimeLocal = (date: Date) => {
    const d = new Date(date);
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title">Título do Evento</Label>
        <Input
          id="title"
          data-testid="input-event-title"
          {...form.register("title")}
          placeholder="Ex: Reunião de Coordenação"
        />
        {form.formState.errors.title && (
          <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="type">Tipo de Evento</Label>
          <Select onValueChange={(value) => form.setValue("type", value)} defaultValue="meeting">
            <SelectTrigger data-testid="select-event-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {eventTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Prioridade</Label>
          <Select onValueChange={(value) => form.setValue("priority", value)} defaultValue="medium">
            <SelectTrigger data-testid="select-event-priority">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {priorities.map((priority) => (
                <SelectItem key={priority.value} value={priority.value}>
                  {priority.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="startDate">Data/Hora de Início</Label>
          <Input
            id="startDate"
            data-testid="input-event-start-date"
            type="datetime-local"
            {...form.register("startDate", {
              setValueAs: (value) => new Date(value)
            })}
            defaultValue={formatDateTimeLocal(new Date())}
          />
          {form.formState.errors.startDate && (
            <p className="text-sm text-destructive">{form.formState.errors.startDate.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="endDate">Data/Hora de Término</Label>
          <Input
            id="endDate"
            data-testid="input-event-end-date"
            type="datetime-local"
            {...form.register("endDate", {
              setValueAs: (value) => new Date(value)
            })}
            defaultValue={formatDateTimeLocal(new Date(Date.now() + 3600000))} // +1 hour
          />
          {form.formState.errors.endDate && (
            <p className="text-sm text-destructive">{form.formState.errors.endDate.message}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="location">Local</Label>
        <Input
          id="location"
          data-testid="input-event-location"
          {...form.register("location")}
          placeholder="Ex: Sala de Reuniões"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="assignedTo">Responsável</Label>
        <Select onValueChange={(value) => form.setValue("assignedTo", value)}>
          <SelectTrigger data-testid="select-event-assigned">
            <SelectValue placeholder="Selecione um responsável (opcional)" />
          </SelectTrigger>
          <SelectContent>
            {(users || []).map((user: any) => (
              <SelectItem key={user.id} value={user.id}>
                {user.fullName} ({user.role})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          data-testid="textarea-event-description"
          {...form.register("description")}
          placeholder="Descreva o evento, agenda, objetivos, etc."
          rows={4}
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          data-testid="button-cancel-event"
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={createEventMutation.isPending}
          data-testid="button-save-event"
        >
          {createEventMutation.isPending ? "Criando..." : "Criar Evento"}
        </Button>
      </div>
    </form>
  );
}
