import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const teacherFormSchema = insertUserSchema.extend({
  role: z.literal("teacher"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type TeacherFormData = z.infer<typeof teacherFormSchema>;

interface TeacherFormProps {
  teacher?: any;
  onClose: () => void;
}

export default function TeacherForm({ teacher, onClose }: TeacherFormProps) {
  const { toast } = useToast();
  const isEditing = !!teacher;

  const specialties = [
    "Matemática",
    "Português",
    "História", 
    "Geografia",
    "Ciências",
    "Educação Física",
    "Artes",
    "Inglês",
    "Química",
    "Física",
    "Biologia",
    "Literatura",
    "Filosofia",
    "Sociologia"
  ];

  const form = useForm<TeacherFormData>({
    resolver: zodResolver(teacherFormSchema),
    defaultValues: {
      username: teacher?.username || "",
      email: teacher?.email || "",
      fullName: teacher?.fullName || "",
      role: "teacher",
      phone: teacher?.phone || "",
      specialty: teacher?.specialty || "",
      status: teacher?.status || "active",
      notes: teacher?.notes || "",
      password: "",
      confirmPassword: "",
    },
  });

  const createTeacherMutation = useMutation({
    mutationFn: async (teacherData: Omit<TeacherFormData, "confirmPassword">) => {
      const res = await apiRequest("POST", "/api/users", {
        ...teacherData,
        password: teacherData.password || "123456", // Default password for new teachers
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Professor cadastrado com sucesso",
      });
      onClose();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTeacherMutation = useMutation({
    mutationFn: async (teacherData: Partial<TeacherFormData>) => {
      const { confirmPassword, ...updateData } = teacherData;
      // Only include password if it was provided
      if (!updateData.password) {
        delete updateData.password;
      }
      const res = await apiRequest("PATCH", `/api/users/${teacher.id}`, updateData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Sucesso",
        description: "Professor atualizado com sucesso",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TeacherFormData) => {
    const { confirmPassword, ...teacherData } = data;
    
    if (isEditing) {
      updateTeacherMutation.mutate(teacherData);
    } else {
      createTeacherMutation.mutate(teacherData);
    }
  };

  const mutation = isEditing ? updateTeacherMutation : createTeacherMutation;

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="fullName">Nome Completo</Label>
          <Input
            id="fullName"
            data-testid="input-teacher-fullname"
            {...form.register("fullName")}
            placeholder="Digite o nome completo"
          />
          {form.formState.errors.fullName && (
            <p className="text-sm text-destructive">{form.formState.errors.fullName.message}</p>
          )}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            data-testid="input-teacher-email"
            type="email"
            {...form.register("email")}
            placeholder="professor@escola.com"
          />
          {form.formState.errors.email && (
            <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
          )}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="username">Usuário</Label>
          <Input
            id="username"
            data-testid="input-teacher-username"
            {...form.register("username")}
            placeholder="Nome de usuário"
            disabled={isEditing}
          />
          {form.formState.errors.username && (
            <p className="text-sm text-destructive">{form.formState.errors.username.message}</p>
          )}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Telefone</Label>
          <Input
            id="phone"
            data-testid="input-teacher-phone"
            {...form.register("phone")}
            placeholder="(11) 99999-9999"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="specialty">Especialidade</Label>
          <Select 
            value={form.watch("specialty") || ""} 
            onValueChange={(value) => form.setValue("specialty", value)}
          >
            <SelectTrigger data-testid="select-teacher-specialty">
              <SelectValue placeholder="Selecione a especialidade" />
            </SelectTrigger>
            <SelectContent>
              {specialties.map((specialty) => (
                <SelectItem key={specialty} value={specialty}>
                  {specialty}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="status">Status</Label>
          <Select 
            value={form.watch("status") || "active"} 
            onValueChange={(value) => form.setValue("status", value)}
          >
            <SelectTrigger data-testid="select-teacher-status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Ativo</SelectItem>
              <SelectItem value="inactive">Inativo</SelectItem>
              <SelectItem value="leave">Licença</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {!isEditing && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              data-testid="input-teacher-password"
              type="password"
              {...form.register("password")}
              placeholder={isEditing ? "Deixe em branco para manter a atual" : "Senha do professor"}
            />
            {form.formState.errors.password && (
              <p className="text-sm text-destructive">{form.formState.errors.password.message}</p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirmar Senha</Label>
            <Input
              id="confirmPassword"
              data-testid="input-teacher-confirm-password"
              type="password"
              {...form.register("confirmPassword")}
              placeholder="Confirme a senha"
            />
            {form.formState.errors.confirmPassword && (
              <p className="text-sm text-destructive">{form.formState.errors.confirmPassword.message}</p>
            )}
          </div>
        </div>
      )}
      
      <div className="space-y-2">
        <Label htmlFor="notes">Observações</Label>
        <Textarea
          id="notes"
          data-testid="textarea-teacher-notes"
          {...form.register("notes")}
          placeholder="Informações adicionais sobre o professor"
          rows={3}
        />
      </div>
      
      <div className="flex justify-end space-x-3 pt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          data-testid="button-cancel-teacher"
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={mutation.isPending}
          data-testid="button-save-teacher"
        >
          {mutation.isPending ? "Salvando..." : isEditing ? "Atualizar Professor" : "Cadastrar Professor"}
        </Button>
      </div>
    </form>
  );
}
