import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertInventoryItemSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type InventoryItemFormData = z.infer<typeof insertInventoryItemSchema>;

interface InventoryFormProps {
  item?: any;
  onClose: () => void;
}

export default function InventoryForm({ item, onClose }: InventoryFormProps) {
  const { toast } = useToast();
  const isEditing = !!item;

  const categories = [
    "Material Escolar",
    "Papelaria", 
    "Limpeza",
    "Informática",
    "Móveis",
    "Equipamentos",
    "Consumíveis",
    "Manutenção",
    "Outros"
  ];

  const units = [
    "unidade",
    "caixa", 
    "pacote",
    "resma",
    "litro",
    "kg",
    "metro",
    "rolo"
  ];

  const form = useForm<InventoryItemFormData>({
    resolver: zodResolver(insertInventoryItemSchema),
    defaultValues: {
      name: item?.name || "",
      description: item?.description || "",
      category: item?.category || "",
      quantity: item?.quantity || 0,
      minQuantity: item?.minQuantity || 10,
      unit: item?.unit || "unidade",
      price: item?.price || "",
      supplier: item?.supplier || "",
      location: item?.location || "",
    },
  });

  const createItemMutation = useMutation({
    mutationFn: async (itemData: InventoryItemFormData) => {
      const res = await apiRequest("POST", "/api/inventory", itemData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/low-stock"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Item adicionado com sucesso",
      });
      onClose();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: async (itemData: InventoryItemFormData) => {
      const res = await apiRequest("PATCH", `/api/inventory/${item.id}`, itemData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/low-stock"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Item atualizado com sucesso",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InventoryItemFormData) => {
    if (isEditing) {
      updateItemMutation.mutate(data);
    } else {
      createItemMutation.mutate(data);
    }
  };

  const mutation = isEditing ? updateItemMutation : createItemMutation;

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="name">Nome do Item</Label>
          <Input
            id="name"
            data-testid="input-item-name"
            {...form.register("name")}
            placeholder="Ex: Papel A4"
          />
          {form.formState.errors.name && (
            <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Categoria</Label>
          <Select 
            value={form.watch("category")} 
            onValueChange={(value) => form.setValue("category", value)}
          >
            <SelectTrigger data-testid="select-item-category">
              <SelectValue placeholder="Selecione a categoria" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.category && (
            <p className="text-sm text-destructive">{form.formState.errors.category.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Quantidade Atual</Label>
          <Input
            id="quantity"
            data-testid="input-item-quantity"
            type="number"
            min="0"
            {...form.register("quantity", { valueAsNumber: true })}
            placeholder="0"
          />
          {form.formState.errors.quantity && (
            <p className="text-sm text-destructive">{form.formState.errors.quantity.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="minQuantity">Quantidade Mínima</Label>
          <Input
            id="minQuantity"
            data-testid="input-item-min-quantity"
            type="number"
            min="0"
            {...form.register("minQuantity", { valueAsNumber: true })}
            placeholder="10"
          />
          {form.formState.errors.minQuantity && (
            <p className="text-sm text-destructive">{form.formState.errors.minQuantity.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="unit">Unidade</Label>
          <Select 
            value={form.watch("unit")} 
            onValueChange={(value) => form.setValue("unit", value)}
          >
            <SelectTrigger data-testid="select-item-unit">
              <SelectValue placeholder="Selecione a unidade" />
            </SelectTrigger>
            <SelectContent>
              {units.map((unit) => (
                <SelectItem key={unit} value={unit}>
                  {unit}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.unit && (
            <p className="text-sm text-destructive">{form.formState.errors.unit.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="price">Preço Unitário (R$)</Label>
          <Input
            id="price"
            data-testid="input-item-price"
            {...form.register("price")}
            placeholder="0.00"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="supplier">Fornecedor</Label>
          <Input
            id="supplier"
            data-testid="input-item-supplier"
            {...form.register("supplier")}
            placeholder="Nome do fornecedor"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="location">Localização</Label>
          <Input
            id="location"
            data-testid="input-item-location"
            {...form.register("location")}
            placeholder="Ex: Armário 2, Prateleira A"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          data-testid="textarea-item-description"
          {...form.register("description")}
          placeholder="Descrição detalhada do item"
          rows={3}
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          data-testid="button-cancel-item"
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={mutation.isPending}
          data-testid="button-save-item"
        >
          {mutation.isPending ? "Salvando..." : isEditing ? "Atualizar Item" : "Adicionar Item"}
        </Button>
      </div>
    </form>
  );
}
