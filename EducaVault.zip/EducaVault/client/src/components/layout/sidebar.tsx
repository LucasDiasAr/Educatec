import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  LayoutDashboard,
  Presentation,
  Users,
  ListTodo,
  Upload,
  Warehouse,
  Calendar,
  AlertTriangle,
  BarChart3,
  TrendingUp,
} from "lucide-react";

interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
  roles: string[];
}

export default function Sidebar() {
  const { user } = useAuth();
  const [location, setLocation] = useLocation();

  const navItems: NavItem[] = [
    {
      title: "Dashboard",
      href: "/",
      icon: LayoutDashboard,
      roles: ["admin", "teacher", "digitizer", "coordinator", "secretary", "assistant_secretary"],
    },
    {
      title: "Professores",
      href: "/teachers",
      icon: Presentation,
      roles: ["admin", "coordinator"],
    },
    {
      title: "Funcionários",
      href: "/staff",
      icon: Users,
      roles: ["admin"],
    },
    {
      title: "Gerenciar Atividades",
      href: "/activities",
      icon: ListTodo,
      badge: 12,
      roles: ["teacher", "digitizer", "coordinator", "admin"],
    },
    {
      title: "Envios Pendentes",
      href: "/submissions",
      icon: Upload,
      badge: 5,
      roles: ["digitizer", "coordinator", "admin"],
    },
    {
      title: "Almoxarifado",
      href: "/inventory",
      icon: Warehouse,
      roles: ["secretary", "assistant_secretary", "admin"],
    },
    {
      title: "Cronograma",
      href: "/calendar",
      icon: Calendar,
      roles: ["digitizer", "coordinator", "secretary", "assistant_secretary", "admin"],
    },
    {
      title: "Ocorrências",
      href: "/incidents",
      icon: AlertTriangle,
      roles: ["teacher", "coordinator", "secretary", "assistant_secretary", "admin"],
    },
    {
      title: "Relatórios",
      href: "/reports",
      icon: BarChart3,
      roles: ["admin", "coordinator"],
    },
    {
      title: "Analytics",
      href: "/analytics",
      icon: TrendingUp,
      roles: ["admin"],
    },
  ];

  const filteredNavItems = navItems.filter(item => 
    item.roles.includes(user?.role || "")
  );

  const handleNavigation = (href: string) => {
    setLocation(href);
  };

  const groupedItems = filteredNavItems.reduce((acc, item) => {
    if (item.href === "/") {
      acc.main.push(item);
    } else if (["/teachers", "/staff"].includes(item.href)) {
      acc.users.push(item);
    } else if (["/activities", "/submissions"].includes(item.href)) {
      acc.activities.push(item);
    } else if (["/inventory", "/calendar", "/incidents"].includes(item.href)) {
      acc.resources.push(item);
    } else {
      acc.reports.push(item);
    }
    return acc;
  }, {
    main: [] as NavItem[],
    users: [] as NavItem[],
    activities: [] as NavItem[],
    resources: [] as NavItem[],
    reports: [] as NavItem[],
  });

  const NavSection = ({ title, items }: { title?: string; items: NavItem[] }) => (
    <div className="space-y-1">
      {title && (
        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-6 mb-2">
          {title}
        </h3>
      )}
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = location === item.href;
        
        return (
          <button
            key={item.href}
            onClick={() => handleNavigation(item.href)}
            className={cn(
              "flex items-center justify-between w-full px-3 py-2 rounded-lg text-sm font-medium transition-colors",
              isActive
                ? "text-primary bg-blue-50"
                : "text-gray-700 hover:text-primary hover:bg-gray-50"
            )}
            data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <div className="flex items-center space-x-3">
              <Icon className="h-5 w-5" />
              <span>{item.title}</span>
            </div>
            
            {item.badge && (
              <Badge 
                variant={item.title.includes("Pendentes") ? "destructive" : "secondary"}
                className="text-xs"
              >
                {item.badge}
              </Badge>
            )}
          </button>
        );
      })}
    </div>
  );

  return (
    <aside className="w-64 bg-white shadow-sm border-r border-gray-200 min-h-screen fixed">
      <div className="p-6">
        <nav className="space-y-2">
          <NavSection items={groupedItems.main} />
          
          {groupedItems.users.length > 0 && (
            <NavSection title="Gestão de Usuários" items={groupedItems.users} />
          )}
          
          {groupedItems.activities.length > 0 && (
            <NavSection title="Atividades" items={groupedItems.activities} />
          )}
          
          {groupedItems.resources.length > 0 && (
            <NavSection title="Recursos" items={groupedItems.resources} />
          )}
          
          {groupedItems.reports.length > 0 && (
            <NavSection title="Relatórios" items={groupedItems.reports} />
          )}
        </nav>
      </div>
    </aside>
  );
}
