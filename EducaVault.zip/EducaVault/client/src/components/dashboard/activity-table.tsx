import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Check, X, Printer } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Activity {
  id: string;
  title: string;
  subject: string;
  status: string;
  createdAt: string;
  teacher?: {
    fullName: string;
  };
  digitizer?: {
    fullName: string;
  };
}

interface ActivityTableProps {
  activities: Activity[];
}

export default function ActivityTable({ activities }: ActivityTableProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateActivityMutation = useMutation({
    mutationFn: async ({ id, status, feedback }: { id: string; status: string; feedback?: string }) => {
      const res = await apiRequest("PATCH", `/api/activities/${id}/status`, { status, feedback });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Status da atividade atualizado com sucesso",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">Pendente</Badge>;
      case "in_review":
        return <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">Em revisão</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">Aprovado</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">Rejeitado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const canApproveReject = (user?.role === 'coordinator' || user?.role === 'admin');
  const canReview = (user?.role === 'digitizer' || user?.role === 'coordinator' || user?.role === 'admin');

  const handleStatusUpdate = (activityId: string, status: string) => {
    updateActivityMutation.mutate({ id: activityId, status });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!activities.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>Nenhuma atividade encontrada</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full">
        <thead>
          <tr className="border-b border-gray-200">
            <th className="text-left py-3 px-4 font-medium text-gray-900">Atividade</th>
            <th className="text-left py-3 px-4 font-medium text-gray-900">Professor</th>
            <th className="text-left py-3 px-4 font-medium text-gray-900">Digitador</th>
            <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
            <th className="text-left py-3 px-4 font-medium text-gray-900">Data</th>
            <th className="text-left py-3 px-4 font-medium text-gray-900">Ações</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {activities.map((activity, index) => (
            <tr key={activity.id} className="hover:bg-gray-50" data-testid={`activity-row-${index}`}>
              <td className="py-4 px-4">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${activity.status === 'approved' ? 'bg-green-50' : 'bg-blue-50'}`}>
                    <Eye className={`h-4 w-4 ${activity.status === 'approved' ? 'text-success' : 'text-primary'}`} />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900" data-testid={`text-activity-title-${index}`}>
                      {activity.title}
                    </p>
                    <p className="text-sm text-gray-600">{activity.subject}</p>
                  </div>
                </div>
              </td>
              
              <td className="py-4 px-4">
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                    <span className="text-white text-sm font-medium">
                      {activity.teacher?.fullName?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <span className="text-sm font-medium text-gray-900" data-testid={`text-teacher-name-${index}`}>
                    {activity.teacher?.fullName}
                  </span>
                </div>
              </td>
              
              <td className="py-4 px-4">
                <span className="text-sm text-gray-600" data-testid={`text-digitizer-name-${index}`}>
                  {activity.digitizer?.fullName || "-"}
                </span>
              </td>
              
              <td className="py-4 px-4">
                {getStatusBadge(activity.status)}
              </td>
              
              <td className="py-4 px-4">
                <span className="text-sm text-gray-600" data-testid={`text-activity-date-${index}`}>
                  {formatDate(activity.createdAt)}
                </span>
              </td>
              
              <td className="py-4 px-4">
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-2 text-gray-400 hover:text-primary"
                    title="Visualizar"
                    data-testid={`button-view-activity-${index}`}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  
                  {activity.status === 'pending' && canReview && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-gray-400 hover:text-blue-600"
                      title="Marcar como em revisão"
                      onClick={() => handleStatusUpdate(activity.id, 'in_review')}
                      disabled={updateActivityMutation.isPending}
                      data-testid={`button-review-activity-${index}`}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                  
                  {(activity.status === 'in_review' || activity.status === 'pending') && canApproveReject && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-2 text-gray-400 hover:text-success"
                        title="Aprovar"
                        onClick={() => handleStatusUpdate(activity.id, 'approved')}
                        disabled={updateActivityMutation.isPending}
                        data-testid={`button-approve-activity-${index}`}
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-2 text-gray-400 hover:text-error"
                        title="Rejeitar"
                        onClick={() => handleStatusUpdate(activity.id, 'rejected')}
                        disabled={updateActivityMutation.isPending}
                        data-testid={`button-reject-activity-${index}`}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                  
                  {activity.status === 'approved' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-gray-400 hover:text-info"
                      title="Imprimir"
                      data-testid={`button-print-activity-${index}`}
                    >
                      <Printer className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
