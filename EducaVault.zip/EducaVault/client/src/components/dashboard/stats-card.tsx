import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  change: string;
  changeType: "positive" | "negative" | "neutral" | "warning";
  icon: LucideIcon;
  iconBg: string;
  iconColor: string;
}

export default function StatsCard({
  title,
  value,
  change,
  changeType,
  icon: Icon,
  iconBg,
  iconColor,
}: StatsCardProps) {
  const getChangeColor = (type: string) => {
    switch (type) {
      case "positive":
        return "text-success";
      case "negative":
        return "text-error";
      case "warning":
        return "text-warning";
      default:
        return "text-info";
    }
  };

  const getChangeIcon = (type: string) => {
    switch (type) {
      case "positive":
        return "↑";
      case "negative":
        return "⚠";
      case "warning":
        return "⏰";
      default:
        return "📅";
    }
  };

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600" data-testid="text-stats-title">
              {title}
            </p>
            <p className="text-3xl font-bold text-gray-900" data-testid="text-stats-value">
              {value}
            </p>
            <p className={`text-sm ${getChangeColor(changeType)}`} data-testid="text-stats-change">
              <span className="mr-1">{getChangeIcon(changeType)}</span>
              {change}
            </p>
          </div>
          <div className={`p-3 ${iconBg} rounded-lg`}>
            <Icon className={`h-6 w-6 ${iconColor}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
