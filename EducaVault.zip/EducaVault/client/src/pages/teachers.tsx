import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Search, Filter, MoreHorizontal, Mail, Phone } from "lucide-react";

const teacherSchema = insertUserSchema.extend({
  role: z.literal("teacher"),
});

type TeacherFormData = z.infer<typeof teacherSchema>;

export default function Teachers() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const { data: teachers, isLoading } = useQuery({
    queryKey: ["/api/users", { role: "teacher" }],
  });

  const addTeacherMutation = useMutation({
    mutationFn: async (teacherData: TeacherFormData) => {
      const res = await apiRequest("POST", "/api/users", {
        ...teacherData,
        password: "123456", // Default password
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Professor cadastrado com sucesso",
      });
      setIsAddDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const form = useForm<TeacherFormData>({
    resolver: zodResolver(teacherSchema),
    defaultValues: {
      username: "",
      email: "",
      fullName: "",
      role: "teacher",
      phone: "",
      specialty: "",
      status: "active",
    },
  });

  const onSubmit = (data: TeacherFormData) => {
    addTeacherMutation.mutate(data);
  };

  const filteredTeachers = teachers?.filter((teacher: any) =>
    teacher.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    teacher.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    teacher.specialty?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  if (user?.role !== 'admin' && user?.role !== 'coordinator') {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex pt-16">
          <Sidebar />
          <main className="flex-1 ml-64 p-8">
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">Você não tem permissão para acessar esta página.</p>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 ml-64 p-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-teachers-title">
                  Gerenciar Professores
                </h1>
                <p className="text-gray-600">Cadastre e gerencie os professores da escola</p>
              </div>
              
              {user?.role === 'admin' && (
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-primary hover:bg-blue-700" data-testid="button-add-teacher">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Cadastrar Professor
                    </Button>
                  </DialogTrigger>
                  
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Cadastrar Novo Professor</DialogTitle>
                    </DialogHeader>
                    
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="fullName">Nome Completo</Label>
                          <Input
                            id="fullName"
                            data-testid="input-teacher-fullname"
                            {...form.register("fullName")}
                            placeholder="Digite o nome completo"
                          />
                          {form.formState.errors.fullName && (
                            <p className="text-sm text-destructive">{form.formState.errors.fullName.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            data-testid="input-teacher-email"
                            type="email"
                            {...form.register("email")}
                            placeholder="professor@escola.com"
                          />
                          {form.formState.errors.email && (
                            <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="username">Usuário</Label>
                          <Input
                            id="username"
                            data-testid="input-teacher-username"
                            {...form.register("username")}
                            placeholder="Nome de usuário"
                          />
                          {form.formState.errors.username && (
                            <p className="text-sm text-destructive">{form.formState.errors.username.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="phone">Telefone</Label>
                          <Input
                            id="phone"
                            data-testid="input-teacher-phone"
                            {...form.register("phone")}
                            placeholder="(11) 99999-9999"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="specialty">Especialidade</Label>
                          <Input
                            id="specialty"
                            data-testid="input-teacher-specialty"
                            {...form.register("specialty")}
                            placeholder="Ex: Matemática, Português..."
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="status">Status</Label>
                          <Select onValueChange={(value) => form.setValue("status", value)} defaultValue="active">
                            <SelectTrigger data-testid="select-teacher-status">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="active">Ativo</SelectItem>
                              <SelectItem value="inactive">Inativo</SelectItem>
                              <SelectItem value="leave">Licença</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-3 pt-4">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setIsAddDialogOpen(false)}
                          data-testid="button-cancel-teacher"
                        >
                          Cancelar
                        </Button>
                        <Button 
                          type="submit" 
                          disabled={addTeacherMutation.isPending}
                          data-testid="button-save-teacher"
                        >
                          {addTeacherMutation.isPending ? "Salvando..." : "Cadastrar Professor"}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>

          {/* Search and Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar por nome, email ou especialidade..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-teachers"
                  />
                </div>
                <Button variant="outline" size="sm" data-testid="button-filter-teachers">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Teachers Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="pt-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              filteredTeachers.map((teacher: any, index: number) => (
                <Card key={teacher.id} className="hover:shadow-md transition-shadow" data-testid={`teacher-card-${index}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center">
                          <span className="text-white text-lg font-medium">
                            {teacher.fullName?.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <CardTitle className="text-lg" data-testid={`text-teacher-name-${index}`}>
                            {teacher.fullName}
                          </CardTitle>
                          <p className="text-sm text-gray-600">{teacher.specialty || "Não informado"}</p>
                        </div>
                      </div>
                      
                      <Button variant="ghost" size="sm" data-testid={`button-teacher-menu-${index}`}>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Mail className="h-4 w-4" />
                        <span data-testid={`text-teacher-email-${index}`}>{teacher.email}</span>
                      </div>
                      
                      {teacher.phone && (
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Phone className="h-4 w-4" />
                          <span>{teacher.phone}</span>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <Badge 
                          variant={teacher.status === 'active' ? 'default' : 'secondary'}
                          data-testid={`badge-teacher-status-${index}`}
                        >
                          {teacher.status === 'active' ? 'Ativo' : 
                           teacher.status === 'inactive' ? 'Inativo' : 'Licença'}
                        </Badge>
                        
                        <span className="text-xs text-gray-500">
                          {teacher.admissionDate ? 
                            `Desde ${new Date(teacher.admissionDate).toLocaleDateString('pt-BR')}` :
                            'Data não informada'
                          }
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {!isLoading && filteredTeachers.length === 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <UserPlus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500" data-testid="text-no-teachers">
                    {searchTerm ? "Nenhum professor encontrado" : "Nenhum professor cadastrado"}
                  </p>
                  {!searchTerm && user?.role === 'admin' && (
                    <Button 
                      className="mt-4" 
                      onClick={() => setIsAddDialogOpen(true)}
                      data-testid="button-add-first-teacher"
                    >
                      Cadastrar primeiro professor
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}
