import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import InventoryForm from "@/components/forms/inventory-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Search, 
  Filter, 
  Package,
  AlertTriangle,
  TrendingDown,
  BarChart3,
  Edit,
  Trash2,
  CheckCircle
} from "lucide-react";

export default function Inventory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);

  const { data: inventoryItems = [], isLoading } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  const updateItemMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PATCH", `/api/inventory/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/low-stock"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Item atualizado com sucesso",
      });
      setEditingItem(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const canManageInventory = ['secretary', 'assistant_secretary', 'admin'].includes(user?.role || '');

  if (!canManageInventory) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex pt-16">
          <Sidebar />
          <main className="flex-1 ml-64 p-8">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Você não tem permissão para acessar o almoxarifado.</p>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    );
  }

  const filteredItems = inventoryItems.filter((item: any) => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(inventoryItems.map((item: any) => item.category))];

  const getStockStatus = (item: any) => {
    if (item.quantity <= item.minQuantity) {
      return { status: 'low', color: 'bg-red-50 text-red-600 border-red-200', label: 'Estoque Baixo' };
    } else if (item.quantity <= item.minQuantity * 1.5) {
      return { status: 'warning', color: 'bg-yellow-50 text-yellow-600 border-yellow-200', label: 'Atenção' };
    } else {
      return { status: 'good', color: 'bg-green-50 text-green-600 border-green-200', label: 'Estoque OK' };
    }
  };

  const handleQuickRestock = (itemId: string, currentQuantity: number) => {
    const newQuantity = currentQuantity + 50; // Add 50 units
    updateItemMutation.mutate({ id: itemId, data: { quantity: newQuantity } });
  };

  const InventoryCard = ({ item, index }: { item: any; index: number }) => {
    const stockStatus = getStockStatus(item);
    
    return (
      <Card className="hover:shadow-md transition-shadow" data-testid={`inventory-card-${index}`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-lg mb-1" data-testid={`text-item-name-${index}`}>
                {item.name}
              </CardTitle>
              <p className="text-sm text-gray-600 mb-2">{item.category}</p>
              {item.description && (
                <p className="text-sm text-gray-500 line-clamp-2">{item.description}</p>
              )}
            </div>
            <Badge variant="outline" className={stockStatus.color}>
              {stockStatus.label}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Quantidade:</span>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-bold text-gray-900" data-testid={`text-item-quantity-${index}`}>
                  {item.quantity}
                </span>
                <span className="text-sm text-gray-500">{item.unit}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Mínimo:</span>
              <span className="text-gray-900">{item.minQuantity} {item.unit}</span>
            </div>
            
            {item.price && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Preço unitário:</span>
                <span className="text-gray-900">R$ {item.price}</span>
              </div>
            )}
            
            {item.supplier && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Fornecedor:</span>
                <span className="text-gray-900">{item.supplier}</span>
              </div>
            )}
            
            {item.location && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Localização:</span>
                <span className="text-gray-900">{item.location}</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center justify-between pt-4 mt-4 border-t">
            <div className="flex space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setEditingItem(item)}
                data-testid={`button-edit-item-${index}`}
              >
                <Edit className="h-4 w-4 mr-1" />
                Editar
              </Button>
            </div>
            
            {stockStatus.status === 'low' && (
              <Button
                size="sm"
                className="bg-primary hover:bg-blue-700"
                onClick={() => handleQuickRestock(item.id, item.quantity)}
                disabled={updateItemMutation.isPending}
                data-testid={`button-restock-item-${index}`}
              >
                <Plus className="h-4 w-4 mr-1" />
                Repor
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 ml-64 p-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-inventory-title">
                  Almoxarifado
                </h1>
                <p className="text-gray-600">Controle de estoque e materiais escolares</p>
              </div>
              
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-blue-700" data-testid="button-add-item">
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Item
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Adicionar Novo Item</DialogTitle>
                  </DialogHeader>
                  <InventoryForm onClose={() => setIsAddDialogOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total de Itens</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-total-items">
                      {inventoryItems?.length || 0}
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <Package className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Estoque Baixo</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-low-stock-count">
                      {lowStockItems?.length || 0}
                    </p>
                    <p className="text-sm text-error">
                      <AlertTriangle className="h-3 w-3 inline mr-1" />
                      Requer atenção
                    </p>
                  </div>
                  <div className="p-3 bg-red-50 rounded-lg">
                    <TrendingDown className="h-6 w-6 text-error" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Categorias</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-categories-count">
                      {categories.length}
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <BarChart3 className="h-6 w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Status Geral</p>
                    <p className="text-lg font-bold text-success">
                      <CheckCircle className="h-5 w-5 inline mr-1" />
                      Bom
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar por nome ou descrição..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-inventory"
                  />
                </div>
                
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-48" data-testid="select-category-filter">
                    <SelectValue placeholder="Todas as categorias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as categorias</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button variant="outline" size="sm" data-testid="button-filter-inventory">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Inventory Tabs */}
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all" data-testid="tab-all-items">
                Todos os Itens
                <Badge variant="secondary" className="ml-2 h-5 w-5 p-0 text-xs">
                  {filteredItems.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="low-stock" data-testid="tab-low-stock">
                Estoque Baixo
                {lowStockItems && lowStockItems.length > 0 && (
                  <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 text-xs">
                    {lowStockItems.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="reports" data-testid="tab-reports">Relatórios</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {isLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="pt-6">
                        <div className="space-y-3">
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                          <div className="h-20 bg-gray-200 rounded"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  filteredItems.map((item: any, index: number) => (
                    <InventoryCard key={item.id} item={item} index={index} />
                  ))
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="low-stock" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {lowStockItems?.map((item: any, index: number) => (
                  <InventoryCard key={item.id} item={item} index={index} />
                ))}
              </div>
              
              {(!lowStockItems || lowStockItems.length === 0) && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-8">
                      <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                      <p className="text-gray-500">Todos os itens estão com estoque adequado!</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="reports" className="mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">Relatórios em desenvolvimento</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {!isLoading && filteredItems.length === 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500" data-testid="text-no-items">
                    {searchTerm ? "Nenhum item encontrado" : "Nenhum item cadastrado"}
                  </p>
                  {!searchTerm && (
                    <Button 
                      className="mt-4" 
                      onClick={() => setIsAddDialogOpen(true)}
                      data-testid="button-add-first-item"
                    >
                      Adicionar primeiro item
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Edit Item Dialog */}
          <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Editar Item</DialogTitle>
              </DialogHeader>
              {editingItem && (
                <InventoryForm 
                  item={editingItem} 
                  onClose={() => setEditingItem(null)} 
                />
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
