import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ActivityForm from "@/components/forms/activity-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Search, 
  Filter, 
  Eye, 
  Check, 
  X, 
  Download,
  Upload,
  FileText,
  Clock,
  CheckCircle,
  XCircle
} from "lucide-react";

export default function Activities() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/activities"],
  });

  const updateActivityMutation = useMutation({
    mutationFn: async ({ id, status, feedback }: { id: string; status: string; feedback?: string }) => {
      const res = await apiRequest("PATCH", `/api/activities/${id}/status`, { status, feedback });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Sucesso",
        description: "Status da atividade atualizado com sucesso",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredActivities = activities?.filter((activity: any) => {
    const matchesSearch = activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || activity.status === statusFilter;
    
    // Teachers can only see their own activities
    if (user?.role === 'teacher') {
      return matchesSearch && matchesStatus && activity.teacherId === user.id;
    }
    
    return matchesSearch && matchesStatus;
  }) || [];

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { variant: "outline", className: "bg-yellow-50 text-yellow-600 border-yellow-200", label: "Pendente", icon: Clock },
      in_review: { variant: "outline", className: "bg-blue-50 text-blue-600 border-blue-200", label: "Em revisão", icon: Eye },
      approved: { variant: "outline", className: "bg-green-50 text-green-600 border-green-200", label: "Aprovado", icon: CheckCircle },
      rejected: { variant: "outline", className: "bg-red-50 text-red-600 border-red-200", label: "Rejeitado", icon: XCircle },
      printed: { variant: "outline", className: "bg-purple-50 text-purple-600 border-purple-200", label: "Impresso", icon: FileText },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    const IconComponent = config.icon;

    return (
      <Badge variant={config.variant as any} className={config.className}>
        <IconComponent className="h-3 w-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const handleStatusUpdate = (activityId: string, status: string) => {
    updateActivityMutation.mutate({ id: activityId, status });
  };

  const canCreateActivity = user?.role === 'teacher';
  const canReview = ['digitizer', 'coordinator', 'admin'].includes(user?.role || '');
  const canApprove = ['coordinator', 'admin'].includes(user?.role || '');

  const getActivitiesByStatus = (status: string) => {
    return filteredActivities.filter((activity: any) => activity.status === status);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const ActivityCard = ({ activity, index }: { activity: any; index: number }) => (
    <Card className="hover:shadow-md transition-shadow" data-testid={`activity-card-${index}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg mb-1" data-testid={`text-activity-title-${index}`}>
              {activity.title}
            </CardTitle>
            <p className="text-sm text-gray-600 mb-2">{activity.subject}</p>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>Por: {activity.teacher?.fullName}</span>
              <span>•</span>
              <span>{formatDate(activity.createdAt)}</span>
            </div>
          </div>
          {getStatusBadge(activity.status)}
        </div>
      </CardHeader>
      
      <CardContent>
        {activity.description && (
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">{activity.description}</p>
        )}
        
        {activity.digitizer && (
          <div className="flex items-center space-x-2 text-sm text-gray-500 mb-2">
            <span>Digitador: {activity.digitizer.fullName}</span>
          </div>
        )}
        
        {activity.feedback && (
          <div className="bg-gray-50 p-3 rounded-lg mb-4">
            <p className="text-sm font-medium text-gray-700 mb-1">Feedback:</p>
            <p className="text-sm text-gray-600">{activity.feedback}</p>
          </div>
        )}
        
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-primary"
              data-testid={`button-view-activity-${index}`}
            >
              <Eye className="h-4 w-4 mr-1" />
              Ver
            </Button>
            
            {activity.fileUrl && (
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-primary"
                data-testid={`button-download-activity-${index}`}
              >
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
            )}
          </div>
          
          <div className="flex space-x-1">
            {activity.status === 'pending' && canReview && (
              <Button
                variant="ghost"
                size="sm"
                className="text-blue-600 hover:text-blue-700"
                onClick={() => handleStatusUpdate(activity.id, 'in_review')}
                disabled={updateActivityMutation.isPending}
                data-testid={`button-review-activity-${index}`}
              >
                <Eye className="h-4 w-4" />
              </Button>
            )}
            
            {['pending', 'in_review'].includes(activity.status) && canApprove && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-green-600 hover:text-green-700"
                  onClick={() => handleStatusUpdate(activity.id, 'approved')}
                  disabled={updateActivityMutation.isPending}
                  data-testid={`button-approve-activity-${index}`}
                >
                  <Check className="h-4 w-4" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-600 hover:text-red-700"
                  onClick={() => handleStatusUpdate(activity.id, 'rejected')}
                  disabled={updateActivityMutation.isPending}
                  data-testid={`button-reject-activity-${index}`}
                >
                  <X className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 ml-64 p-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-activities-title">
                  Atividades Escolares
                </h1>
                <p className="text-gray-600">
                  {user?.role === 'teacher' ? 'Envie e acompanhe suas atividades' : 'Gerencie o fluxo de atividades'}
                </p>
              </div>
              
              {canCreateActivity && (
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-primary hover:bg-blue-700" data-testid="button-add-activity">
                      <Plus className="h-4 w-4 mr-2" />
                      Nova Atividade
                    </Button>
                  </DialogTrigger>
                  
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Enviar Nova Atividade</DialogTitle>
                    </DialogHeader>
                    <ActivityForm onClose={() => setIsAddDialogOpen(false)} />
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>

          {/* Search and Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar por título ou matéria..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-activities"
                  />
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48" data-testid="select-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="in_review">Em revisão</SelectItem>
                    <SelectItem value="approved">Aprovado</SelectItem>
                    <SelectItem value="rejected">Rejeitado</SelectItem>
                    <SelectItem value="printed">Impresso</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button variant="outline" size="sm" data-testid="button-filter-activities">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Activities Content */}
          {user?.role === 'teacher' ? (
            // Teacher view - simple grid
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {isLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="pt-6">
                      <div className="space-y-3">
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        <div className="h-20 bg-gray-200 rounded"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                filteredActivities.map((activity: any, index: number) => (
                  <ActivityCard key={activity.id} activity={activity} index={index} />
                ))
              )}
            </div>
          ) : (
            // Admin/Coordinator/Digitizer view - tabs by status
            <Tabs defaultValue="pending" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="pending" className="relative" data-testid="tab-pending">
                  Pendentes
                  {getActivitiesByStatus('pending').length > 0 && (
                    <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 text-xs">
                      {getActivitiesByStatus('pending').length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="in_review" data-testid="tab-review">
                  Em Revisão
                  {getActivitiesByStatus('in_review').length > 0 && (
                    <Badge variant="secondary" className="ml-2 h-5 w-5 p-0 text-xs">
                      {getActivitiesByStatus('in_review').length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="approved" data-testid="tab-approved">Aprovadas</TabsTrigger>
                <TabsTrigger value="rejected" data-testid="tab-rejected">Rejeitadas</TabsTrigger>
                <TabsTrigger value="printed" data-testid="tab-printed">Impressas</TabsTrigger>
              </TabsList>
              
              {['pending', 'in_review', 'approved', 'rejected', 'printed'].map((status) => (
                <TabsContent key={status} value={status} className="mt-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {getActivitiesByStatus(status).map((activity: any, index: number) => (
                      <ActivityCard key={activity.id} activity={activity} index={index} />
                    ))}
                  </div>
                  
                  {getActivitiesByStatus(status).length === 0 && (
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-center py-8">
                          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-500">
                            Nenhuma atividade {status === 'pending' ? 'pendente' : 
                                              status === 'in_review' ? 'em revisão' :
                                              status === 'approved' ? 'aprovada' :
                                              status === 'rejected' ? 'rejeitada' : 'impressa'}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          )}

          {!isLoading && filteredActivities.length === 0 && statusFilter === 'all' && (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500" data-testid="text-no-activities">
                    {searchTerm ? "Nenhuma atividade encontrada" : "Nenhuma atividade cadastrada"}
                  </p>
                  {!searchTerm && canCreateActivity && (
                    <Button 
                      className="mt-4" 
                      onClick={() => setIsAddDialogOpen(true)}
                      data-testid="button-add-first-activity"
                    >
                      Enviar primeira atividade
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}
