import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import StatsCard from "@/components/dashboard/stats-card";
import ActivityTable from "@/components/dashboard/activity-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Presentation, 
  ListTodo, 
  Warehouse, 
  Calendar,
  UserPlus,
  CheckCircle,
  Package,
  Clock,
  Users,
  AlertTriangle,
  Eye,
  Check,
  X,
  Download,
  Filter
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: activities } = useQuery({
    queryKey: ["/api/activities"],
  });

  const { data: lowStockItems } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  const { data: todaysEvents } = useQuery({
    queryKey: ["/api/calendar/events"],
  });

  const quickActions = [
    {
      title: "Cadastrar Professor",
      description: "Adicionar novo docente",
      icon: UserPlus,
      bgColor: "bg-blue-50 hover:bg-blue-100",
      iconColor: "bg-primary",
      action: "addTeacher",
      roles: ["admin"],
    },
    {
      title: "Revisar Atividades",
      description: `${stats?.pendingActivities || 0} pendentes`,
      icon: CheckCircle,
      bgColor: "bg-green-50 hover:bg-green-100",
      iconColor: "bg-success",
      action: "reviewActivities",
      roles: ["digitizer", "coordinator", "admin"],
    },
    {
      title: "Gerenciar Estoque",
      description: `${stats?.lowStock || 0} itens baixos`,
      icon: Package,
      bgColor: "bg-orange-50 hover:bg-orange-100",
      iconColor: "bg-warning",
      action: "manageInventory",
      roles: ["secretary", "assistant_secretary", "admin"],
    },
  ];

  const filteredQuickActions = quickActions.filter(action => 
    action.roles.includes(user?.role || "")
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">Pendente</Badge>;
      case "in_review":
        return <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">Em revisão</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">Aprovado</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">Rejeitado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 ml-64 p-8">
          {/* Dashboard Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-dashboard-title">
              Dashboard Principal
            </h1>
            <p className="text-gray-600">Bem-vindo ao sistema da Escola Liberalina Paes Landim</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              title="Total de Professores"
              value={statsLoading ? "..." : stats?.teachers || 0}
              change="+3 este mês"
              changeType="positive"
              icon={Presentation}
              iconBg="bg-blue-50"
              iconColor="text-primary"
            />
            
            <StatsCard
              title="Atividades Pendentes"
              value={statsLoading ? "..." : stats?.pendingActivities || 0}
              change="Para revisão"
              changeType="warning"
              icon={ListTodo}
              iconBg="bg-orange-50"
              iconColor="text-warning"
            />
            
            <StatsCard
              title="Estoque Baixo"
              value={statsLoading ? "..." : stats?.lowStock || 0}
              change="Requer atenção"
              changeType="negative"
              icon={Warehouse}
              iconBg="bg-red-50"
              iconColor="text-error"
            />
            
            <StatsCard
              title="Eventos Hoje"
              value={statsLoading ? "..." : stats?.todayEvents || 0}
              change="No cronograma"
              changeType="neutral"
              icon={Calendar}
              iconBg="bg-green-50"
              iconColor="text-success"
            />
          </div>

          {/* Quick Actions & Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Quick Actions */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Ações Rápidas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {filteredQuickActions.map((action, index) => {
                      const IconComponent = action.icon;
                      return (
                        <Button
                          key={index}
                          variant="ghost"
                          className={`w-full flex items-center space-x-3 p-3 h-auto justify-start ${action.bgColor} transition-colors`}
                          data-testid={`button-${action.action}`}
                        >
                          <div className={`p-2 ${action.iconColor} rounded-lg`}>
                            <IconComponent className="h-4 w-4 text-white" />
                          </div>
                          <div className="text-left">
                            <p className="font-medium text-gray-900">{action.title}</p>
                            <p className="text-sm text-gray-600">{action.description}</p>
                          </div>
                        </Button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-lg font-semibold text-gray-900">Atividade Recente</CardTitle>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-blue-800">
                    Ver todas
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activities?.slice(0, 3).map((activity: any, index: number) => (
                      <div key={activity.id} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg" data-testid={`activity-${index}`}>
                        <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                          <ListTodo className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900" data-testid={`text-activity-title-${index}`}>
                            Nova atividade: {activity.title}
                          </p>
                          <p className="text-sm text-gray-600">
                            {activity.subject} - {activity.teacher?.fullName}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(activity.createdAt).toLocaleString('pt-BR')}
                          </p>
                        </div>
                        {getStatusBadge(activity.status)}
                      </div>
                    ))}

                    {lowStockItems?.slice(0, 1).map((item: any, index: number) => (
                      <div key={item.id} className="flex items-start space-x-4 p-4 bg-red-50 rounded-lg border border-red-200">
                        <div className="p-2 bg-error rounded-lg flex-shrink-0">
                          <AlertTriangle className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900">Estoque baixo</p>
                          <p className="text-sm text-gray-600">
                            {item.name} - apenas {item.quantity} unidades restantes
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(item.updatedAt).toLocaleString('pt-BR')}
                          </p>
                        </div>
                        <Badge variant="destructive">Urgente</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Activity Management Section */}
          {(user?.role === 'digitizer' || user?.role === 'coordinator' || user?.role === 'admin') && (
            <Card className="mb-8">
              <CardHeader className="border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl font-semibold text-gray-900">
                      Gerenciamento de Atividades
                    </CardTitle>
                    <p className="text-gray-600 mt-1">Fluxo completo desde envio até aprovação</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="default" size="sm" data-testid="button-export-activities">
                      <Download className="h-4 w-4 mr-2" />
                      Exportar
                    </Button>
                    <Button variant="outline" size="sm" data-testid="button-filter-activities">
                      <Filter className="h-4 w-4 mr-2" />
                      Filtrar
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <ActivityTable activities={activities || []} />
              </CardContent>
            </Card>
          )}

          {/* Inventory Overview & Calendar */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Stock Alerts */}
            {(user?.role === 'secretary' || user?.role === 'assistant_secretary' || user?.role === 'admin') && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Alertas de Estoque</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {lowStockItems?.map((item: any) => (
                      <div key={item.id} className="flex items-center justify-between p-4 bg-red-50 rounded-lg border border-red-200">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-error rounded-lg">
                            <AlertTriangle className="h-4 w-4 text-white" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900" data-testid={`text-stock-item-${item.id}`}>
                              {item.name}
                            </p>
                            <p className="text-sm text-gray-600">
                              {item.quantity} {item.unit} restantes
                            </p>
                          </div>
                        </div>
                        <Button 
                          size="sm" 
                          className="bg-error hover:bg-red-700 text-white"
                          data-testid={`button-restock-${item.id}`}
                        >
                          Repor
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Calendar Overview */}
            {user?.role !== 'teacher' && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-lg font-semibold text-gray-900">Cronograma - Hoje</CardTitle>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-blue-800">
                    Ver calendário
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {todaysEvents?.map((event: any, index: number) => (
                      <div key={event.id} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                        <div className="p-2 bg-primary rounded-lg mt-1">
                          <Clock className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900" data-testid={`text-event-title-${index}`}>
                            {event.title}
                          </p>
                          <p className="text-sm text-gray-600">
                            {formatTime(event.startDate)} - {formatTime(event.endDate)}
                          </p>
                          {event.location && (
                            <p className="text-sm text-gray-500">{event.location}</p>
                          )}
                        </div>
                      </div>
                    ))}
                    
                    {!todaysEvents?.length && (
                      <div className="text-center py-8 text-gray-500">
                        <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>Nenhum evento agendado para hoje</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
