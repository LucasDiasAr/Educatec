import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import IncidentForm from "@/components/forms/incident-form";
import { 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle,
  Heart,
  User,
  BookOpen,
  FileText,
  CheckCircle,
  Clock,
  Phone
} from "lucide-react";

export default function Incidents() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const { data: incidents = [], isLoading } = useQuery({
    queryKey: ["/api/incidents"],
  });

  const filteredIncidents = incidents.filter((incident: any) => {
    const matchesSearch = incident.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         incident.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         incident.studentClass.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === "all" || incident.incidentType === typeFilter;
    const matchesStatus = statusFilter === "all" || 
                         (statusFilter === "resolved" && incident.resolved) ||
                         (statusFilter === "pending" && !incident.resolved);
    return matchesSearch && matchesType && matchesStatus;
  });

  const getIncidentTypeIcon = (type: string) => {
    switch (type) {
      case 'health':
        return Heart;
      case 'behavior':
        return User;
      case 'academic':
        return BookOpen;
      default:
        return FileText;
    }
  };

  const getIncidentTypeLabel = (type: string) => {
    const labels = {
      health: "Saúde",
      behavior: "Comportamento",
      academic: "Acadêmico",
      other: "Outros"
    };
    return labels[type as keyof typeof labels] || "Outros";
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return <Badge variant="destructive">Alta</Badge>;
      case 'medium':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">Média</Badge>;
      case 'low':
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">Baixa</Badge>;
      default:
        return <Badge variant="outline">Baixa</Badge>;
    }
  };

  const getIncidentsByType = (type: string) => {
    return filteredIncidents.filter((incident: any) => incident.incidentType === type);
  };

  const getIncidentsByStatus = (resolved: boolean) => {
    return filteredIncidents.filter((incident: any) => incident.resolved === resolved);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const IncidentCard = ({ incident, index }: { incident: any; index: number }) => {
    const IconComponent = getIncidentTypeIcon(incident.incidentType);
    
    return (
      <Card className="hover:shadow-md transition-shadow" data-testid={`incident-card-${index}`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3 flex-1">
              <div className={`p-2 rounded-lg ${
                incident.incidentType === 'health' ? 'bg-red-50' :
                incident.incidentType === 'behavior' ? 'bg-orange-50' :
                incident.incidentType === 'academic' ? 'bg-blue-50' : 'bg-gray-50'
              }`}>
                <IconComponent className={`h-5 w-5 ${
                  incident.incidentType === 'health' ? 'text-red-600' :
                  incident.incidentType === 'behavior' ? 'text-orange-600' :
                  incident.incidentType === 'academic' ? 'text-blue-600' : 'text-gray-600'
                }`} />
              </div>
              <div className="flex-1 min-w-0">
                <CardTitle className="text-lg mb-1" data-testid={`text-incident-title-${index}`}>
                  {incident.title}
                </CardTitle>
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                  <span className="font-medium" data-testid={`text-student-name-${index}`}>
                    {incident.studentName}
                  </span>
                  <span>•</span>
                  <span>{incident.studentClass}</span>
                  <span>•</span>
                  <span>{getIncidentTypeLabel(incident.incidentType)}</span>
                </div>
                <p className="text-sm text-gray-500">
                  Reportado em {formatDate(incident.createdAt)}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {getSeverityBadge(incident.severity)}
              {incident.resolved ? (
                <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Resolvido
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">
                  <Clock className="h-3 w-3 mr-1" />
                  Pendente
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Descrição:</p>
              <p className="text-sm text-gray-600 line-clamp-3">{incident.description}</p>
            </div>
            
            {incident.actionTaken && (
              <div>
                <p className="text-sm font-medium text-gray-700 mb-2">Ação tomada:</p>
                <p className="text-sm text-gray-600">{incident.actionTaken}</p>
              </div>
            )}
            
            <div className="flex items-center justify-between pt-2 border-t">
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span>Por: {incident.reportedBy?.fullName}</span>
                {incident.parentNotified && (
                  <div className="flex items-center space-x-1 text-blue-600">
                    <Phone className="h-3 w-3" />
                    <span>Pais notificados</span>
                  </div>
                )}
              </div>
              
              <div className="flex space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  data-testid={`button-view-incident-${index}`}
                >
                  Ver detalhes
                </Button>
                
                {!incident.resolved && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-green-600 hover:text-green-700"
                    data-testid={`button-resolve-incident-${index}`}
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Resolver
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 ml-64 p-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-incidents-title">
                  Ocorrências Estudantis
                </h1>
                <p className="text-gray-600">Registre e acompanhe ocorrências com estudantes</p>
              </div>
              
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-blue-700" data-testid="button-add-incident">
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Ocorrência
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Registrar Nova Ocorrência</DialogTitle>
                  </DialogHeader>
                  <IncidentForm onClose={() => setIsAddDialogOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-total-incidents">
                      {incidents?.length || 0}
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Pendentes</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-pending-incidents">
                      {getIncidentsByStatus(false).length}
                    </p>
                    <p className="text-sm text-warning">
                      <Clock className="h-3 w-3 inline mr-1" />
                      Aguardando ação
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <Clock className="h-6 w-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Resolvidas</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-resolved-incidents">
                      {getIncidentsByStatus(true).length}
                    </p>
                    <p className="text-sm text-success">
                      <CheckCircle className="h-3 w-3 inline mr-1" />
                      Concluídas
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Saúde</p>
                    <p className="text-3xl font-bold text-gray-900" data-testid="text-health-incidents">
                      {getIncidentsByType('health').length}
                    </p>
                    <p className="text-sm text-error">
                      <Heart className="h-3 w-3 inline mr-1" />
                      Mais críticas
                    </p>
                  </div>
                  <div className="p-3 bg-red-50 rounded-lg">
                    <Heart className="h-6 w-6 text-error" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar por aluno, título ou turma..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-incidents"
                  />
                </div>
                
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-48" data-testid="select-type-filter">
                    <SelectValue placeholder="Todos os tipos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os tipos</SelectItem>
                    <SelectItem value="health">Saúde</SelectItem>
                    <SelectItem value="behavior">Comportamento</SelectItem>
                    <SelectItem value="academic">Acadêmico</SelectItem>
                    <SelectItem value="other">Outros</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48" data-testid="select-status-filter">
                    <SelectValue placeholder="Todos os status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="pending">Pendentes</SelectItem>
                    <SelectItem value="resolved">Resolvidas</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button variant="outline" size="sm" data-testid="button-filter-incidents">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Incidents Tabs */}
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all" data-testid="tab-all-incidents">
                Todas
                <Badge variant="secondary" className="ml-2 h-5 w-5 p-0 text-xs">
                  {filteredIncidents.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="pending" data-testid="tab-pending-incidents">
                Pendentes
                {getIncidentsByStatus(false).length > 0 && (
                  <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 text-xs">
                    {getIncidentsByStatus(false).length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="health" data-testid="tab-health-incidents">
                Saúde
                {getIncidentsByType('health').length > 0 && (
                  <Badge variant="outline" className="ml-2 h-5 w-5 p-0 text-xs bg-red-50 text-red-600 border-red-200">
                    {getIncidentsByType('health').length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="resolved" data-testid="tab-resolved-incidents">Resolvidas</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-6">
              <div className="space-y-4">
                {isLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="pt-6">
                        <div className="space-y-3">
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                          <div className="h-20 bg-gray-200 rounded"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  filteredIncidents.map((incident: any, index: number) => (
                    <IncidentCard key={incident.id} incident={incident} index={index} />
                  ))
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="pending" className="mt-6">
              <div className="space-y-4">
                {getIncidentsByStatus(false).map((incident: any, index: number) => (
                  <IncidentCard key={incident.id} incident={incident} index={index} />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="health" className="mt-6">
              <div className="space-y-4">
                {getIncidentsByType('health').map((incident: any, index: number) => (
                  <IncidentCard key={incident.id} incident={incident} index={index} />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="resolved" className="mt-6">
              <div className="space-y-4">
                {getIncidentsByStatus(true).map((incident: any, index: number) => (
                  <IncidentCard key={incident.id} incident={incident} index={index} />
                ))}
              </div>
            </TabsContent>
          </Tabs>

          {!isLoading && filteredIncidents.length === 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500" data-testid="text-no-incidents">
                    {searchTerm || typeFilter !== 'all' || statusFilter !== 'all' ? 
                      "Nenhuma ocorrência encontrada" : "Nenhuma ocorrência registrada"}
                  </p>
                  {!searchTerm && typeFilter === 'all' && statusFilter === 'all' && (
                    <Button 
                      className="mt-4" 
                      onClick={() => setIsAddDialogOpen(true)}
                      data-testid="button-add-first-incident"
                    >
                      Registrar primeira ocorrência
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}
