import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import EventForm from "@/components/forms/event-form";
import { 
  Plus, 
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Users,
  CheckCircle,
  AlertCircle
} from "lucide-react";

export default function Calendar() {
  const { user } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  const { data: todaysEvents = [] } = useQuery({
    queryKey: ["/api/calendar/events"],
  });

  const canManageCalendar = user?.role !== 'teacher';

  if (!canManageCalendar) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex pt-16">
          <Sidebar />
          <main className="flex-1 ml-64 p-8">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <CalendarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Professores não têm acesso ao cronograma.</p>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    );
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="destructive">Alta</Badge>;
      case 'medium':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">Média</Badge>;
      case 'low':
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">Baixa</Badge>;
      default:
        return <Badge variant="outline">Média</Badge>;
    }
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case 'meeting':
        return 'bg-blue-50 border-blue-200 text-blue-700';
      case 'task':
        return 'bg-green-50 border-green-200 text-green-700';
      case 'deadline':
        return 'bg-red-50 border-red-200 text-red-700';
      case 'event':
        return 'bg-purple-50 border-purple-200 text-purple-700';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-700';
    }
  };

  const EventCard = ({ event, index }: { event: any; index: number }) => (
    <Card className={`hover:shadow-md transition-shadow border-l-4 ${getEventTypeColor(event.type)}`} data-testid={`event-card-${index}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg mb-1" data-testid={`text-event-title-${index}`}>
              {event.title}
            </CardTitle>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>{formatTime(event.startDate)} - {formatTime(event.endDate)}</span>
              </div>
              {event.location && (
                <div className="flex items-center space-x-1">
                  <MapPin className="h-4 w-4" />
                  <span>{event.location}</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {getPriorityBadge(event.priority)}
            {event.completed && (
              <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                <CheckCircle className="h-3 w-3 mr-1" />
                Concluído
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {event.description && (
          <p className="text-sm text-gray-600 mb-4">{event.description}</p>
        )}
        
        {event.assignedUser && (
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <Users className="h-4 w-4" />
            <span>Responsável: {event.assignedUser.fullName}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 ml-64 p-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-calendar-title">
                  Cronograma
                </h1>
                <p className="text-gray-600">Gerencie eventos, tarefas e compromissos</p>
              </div>
              
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-blue-700" data-testid="button-add-event">
                    <Plus className="h-4 w-4 mr-2" />
                    Novo Evento
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Criar Novo Evento</DialogTitle>
                  </DialogHeader>
                  <EventForm onClose={() => setIsAddDialogOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Today's Events */}
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CalendarIcon className="h-5 w-5 text-primary" />
                  <span>Eventos de Hoje</span>
                  <Badge variant="secondary" className="ml-2">
                    {todaysEvents?.length || 0}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {todaysEvents && todaysEvents.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {todaysEvents.map((event: any, index: number) => (
                      <EventCard key={event.id} event={event} index={index} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CalendarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500" data-testid="text-no-events-today">
                      Nenhum evento agendado para hoje
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Calendar Grid Placeholder */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Calendar View */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Calendário</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <CalendarIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Visualização do calendário em desenvolvimento</p>
                    <p className="text-sm text-gray-400 mt-2">
                      Por enquanto, use a lista de eventos à direita
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar with upcoming events */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Próximos Eventos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {todaysEvents?.slice(0, 5).map((event: any, index: number) => (
                      <div key={event.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div className={`p-2 rounded-lg mt-1 ${
                          event.type === 'meeting' ? 'bg-blue-500' :
                          event.type === 'task' ? 'bg-green-500' :
                          event.type === 'deadline' ? 'bg-red-500' : 'bg-purple-500'
                        }`}>
                          <Clock className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 text-sm" data-testid={`text-upcoming-event-${index}`}>
                            {event.title}
                          </p>
                          <p className="text-sm text-gray-600">
                            {formatTime(event.startDate)}
                          </p>
                          {event.location && (
                            <p className="text-sm text-gray-500">{event.location}</p>
                          )}
                        </div>
                      </div>
                    ))}
                    
                    {(!todaysEvents || todaysEvents.length === 0) && (
                      <div className="text-center py-4">
                        <p className="text-sm text-gray-500">Nenhum evento próximo</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center space-x-2">
                    <AlertCircle className="h-5 w-5 text-orange-500" />
                    <span>Lembretes</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <p className="text-sm font-medium text-orange-700">Reunião de coordenação</p>
                      <p className="text-sm text-orange-600">Amanhã às 9h</p>
                    </div>
                    
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-sm font-medium text-blue-700">Prazo para relatórios</p>
                      <p className="text-sm text-blue-600">Sexta-feira</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
