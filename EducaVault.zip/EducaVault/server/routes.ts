import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertUserSchema, insertActivitySchema, insertInventoryItemSchema, insertCalendarEventSchema, insertStudentIncidentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // User management routes
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated() || !['admin', 'coordinator'].includes(req.user?.role)) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    const { role } = req.query;
    if (role) {
      const users = await storage.getAllUsersByRole(role as string);
      return res.json(users);
    }
    
    const teachers = await storage.getAllUsersByRole('teacher');
    res.json(teachers);
  });

  app.post("/api/users", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== 'admin') {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Activity management routes
  app.get("/api/activities", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const { status, teacherId } = req.query;
    
    if (teacherId && req.user?.role === 'teacher' && req.user.id === teacherId) {
      const activities = await storage.getActivitiesByTeacher(teacherId as string);
      return res.json(activities);
    }
    
    if (status) {
      const activities = await storage.getActivitiesByStatus(status as string);
      return res.json(activities);
    }
    
    const activities = await storage.getAllActivities();
    res.json(activities);
  });

  app.post("/api/activities", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== 'teacher') {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const activityData = insertActivitySchema.parse({
        ...req.body,
        teacherId: req.user.id,
        status: 'pending'
      });
      
      const activity = await storage.createActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/activities/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const { id } = req.params;
    const { status, feedback } = req.body;
    
    // Check permissions based on role and status
    const userRole = req.user?.role;
    if (
      (status === 'in_review' && !['digitizer', 'coordinator', 'admin'].includes(userRole)) ||
      (status === 'approved' && !['coordinator', 'admin'].includes(userRole)) ||
      (status === 'rejected' && !['coordinator', 'admin'].includes(userRole))
    ) {
      return res.status(403).json({ message: "Unauthorized for this action" });
    }
    
    try {
      const activity = await storage.updateActivityStatus(id, status, feedback, req.user?.id);
      res.json(activity);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Inventory management routes
  app.get("/api/inventory", async (req, res) => {
    if (!req.isAuthenticated() || !['secretary', 'assistant_secretary', 'admin'].includes(req.user?.role)) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    const items = await storage.getAllInventoryItems();
    res.json(items);
  });

  app.get("/api/inventory/low-stock", async (req, res) => {
    if (!req.isAuthenticated() || !['secretary', 'assistant_secretary', 'admin'].includes(req.user?.role)) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    const items = await storage.getLowStockItems();
    res.json(items);
  });

  app.post("/api/inventory", async (req, res) => {
    if (!req.isAuthenticated() || !['secretary', 'assistant_secretary', 'admin'].includes(req.user?.role)) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const itemData = insertInventoryItemSchema.parse(req.body);
      const item = await storage.createInventoryItem(itemData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/inventory/:id", async (req, res) => {
    if (!req.isAuthenticated() || !['secretary', 'assistant_secretary', 'admin'].includes(req.user?.role)) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const { id } = req.params;
      const updateData = req.body;
      const item = await storage.updateInventoryItem(id, updateData);
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Calendar routes
  app.get("/api/calendar/events", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    if (req.user?.role === 'teacher') {
      return res.status(403).json({ message: "Teachers do not have access to calendar" });
    }
    
    const { startDate, endDate, userId } = req.query;
    
    if (startDate && endDate) {
      const events = await storage.getEventsByDateRange(new Date(startDate as string), new Date(endDate as string));
      return res.json(events);
    }
    
    if (userId) {
      const events = await storage.getEventsByUser(userId as string);
      return res.json(events);
    }
    
    const todaysEvents = await storage.getTodaysEvents();
    res.json(todaysEvents);
  });

  app.post("/api/calendar/events", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role === 'teacher') {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const eventData = insertCalendarEventSchema.parse({
        ...req.body,
        createdBy: req.user?.id
      });
      
      const event = await storage.createCalendarEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Student incidents routes
  app.get("/api/incidents", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const { studentName } = req.query;
    
    if (studentName) {
      const incidents = await storage.getIncidentsByStudent(studentName as string);
      return res.json(incidents);
    }
    
    const incidents = await storage.getAllStudentIncidents();
    res.json(incidents);
  });

  app.post("/api/incidents", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const incidentData = insertStudentIncidentSchema.parse({
        ...req.body,
        reportedBy: req.user?.id
      });
      
      const incident = await storage.createStudentIncident(incidentData);
      res.status(201).json(incident);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/incidents/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { id } = req.params;
      const updateData = req.body;
      const incident = await storage.updateStudentIncident(id, updateData);
      res.json(incident);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard statistics
  app.get("/api/dashboard/stats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const stats = await storage.getDashboardStats();
    res.json(stats);
  });

  const httpServer = createServer(app);
  return httpServer;
}
