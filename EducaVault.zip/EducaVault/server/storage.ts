import { users, activities, inventoryItems, calendarEvents, studentIncidents, type User, type InsertUser, type Activity, type InsertActivity, type InventoryItem, type InsertInventoryItem, type CalendarEvent, type InsertCalendarEvent, type StudentIncident, type InsertStudentIncident } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User>;
  getAllUsersByRole(role: string): Promise<User[]>;
  
  // Activity management
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivitiesByTeacher(teacherId: string): Promise<Activity[]>;
  getActivitiesByStatus(status: string): Promise<Activity[]>;
  updateActivityStatus(id: string, status: string, feedback?: string, userId?: string): Promise<Activity>;
  getActivityById(id: string): Promise<Activity | undefined>;
  getAllActivities(): Promise<Activity[]>;
  
  // Inventory management
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  getAllInventoryItems(): Promise<InventoryItem[]>;
  updateInventoryItem(id: string, item: Partial<InsertInventoryItem>): Promise<InventoryItem>;
  getLowStockItems(): Promise<InventoryItem[]>;
  getInventoryItemById(id: string): Promise<InventoryItem | undefined>;
  
  // Calendar management
  createCalendarEvent(event: InsertCalendarEvent): Promise<CalendarEvent>;
  getEventsByDateRange(startDate: Date, endDate: Date): Promise<CalendarEvent[]>;
  getEventsByUser(userId: string): Promise<CalendarEvent[]>;
  updateCalendarEvent(id: string, event: Partial<InsertCalendarEvent>): Promise<CalendarEvent>;
  getTodaysEvents(): Promise<CalendarEvent[]>;
  
  // Student incidents
  createStudentIncident(incident: InsertStudentIncident): Promise<StudentIncident>;
  getAllStudentIncidents(): Promise<StudentIncident[]>;
  getIncidentsByStudent(studentName: string): Promise<StudentIncident[]>;
  updateStudentIncident(id: string, incident: Partial<InsertStudentIncident>): Promise<StudentIncident>;
  
  // Dashboard statistics
  getDashboardStats(): Promise<any>;
  
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ pool, createTableIfMissing: true });
  }

  // User management
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, updateData: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  // Activity management
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  async getActivitiesByTeacher(teacherId: string): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.teacherId, teacherId))
      .orderBy(desc(activities.createdAt));
  }

  async getActivitiesByStatus(status: string): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.status, status))
      .orderBy(desc(activities.createdAt));
  }

  async updateActivityStatus(id: string, status: string, feedback?: string, userId?: string): Promise<Activity> {
    const updateData: any = { status, updatedAt: new Date() };
    if (feedback) updateData.feedback = feedback;
    if (userId && status === 'in_review') updateData.digitizerId = userId;
    if (userId && status === 'approved') updateData.coordinatorId = userId;
    
    const [activity] = await db
      .update(activities)
      .set(updateData)
      .where(eq(activities.id, id))
      .returning();
    return activity;
  }

  async getActivityById(id: string): Promise<Activity | undefined> {
    const [activity] = await db.select().from(activities).where(eq(activities.id, id));
    return activity || undefined;
  }

  async getAllActivities(): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .orderBy(desc(activities.createdAt));
  }

  // Inventory management
  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [newItem] = await db.insert(inventoryItems).values(item).returning();
    return newItem;
  }

  async getAllInventoryItems(): Promise<InventoryItem[]> {
    return await db
      .select()
      .from(inventoryItems)
      .orderBy(inventoryItems.name);
  }

  async updateInventoryItem(id: string, updateData: Partial<InsertInventoryItem>): Promise<InventoryItem> {
    const [item] = await db
      .update(inventoryItems)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(inventoryItems.id, id))
      .returning();
    return item;
  }

  async getLowStockItems(): Promise<InventoryItem[]> {
    return await db
      .select()
      .from(inventoryItems)
      .where(sql`${inventoryItems.quantity} <= ${inventoryItems.minQuantity}`);
  }

  async getInventoryItemById(id: string): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    return item || undefined;
  }

  // Calendar management
  async createCalendarEvent(event: InsertCalendarEvent): Promise<CalendarEvent> {
    const [newEvent] = await db.insert(calendarEvents).values(event).returning();
    return newEvent;
  }

  async getEventsByDateRange(startDate: Date, endDate: Date): Promise<CalendarEvent[]> {
    return await db
      .select()
      .from(calendarEvents)
      .where(and(
        sql`${calendarEvents.startDate} >= ${startDate}`,
        sql`${calendarEvents.endDate} <= ${endDate}`
      ))
      .orderBy(calendarEvents.startDate);
  }

  async getEventsByUser(userId: string): Promise<CalendarEvent[]> {
    return await db
      .select()
      .from(calendarEvents)
      .where(eq(calendarEvents.assignedTo, userId))
      .orderBy(calendarEvents.startDate);
  }

  async updateCalendarEvent(id: string, updateData: Partial<InsertCalendarEvent>): Promise<CalendarEvent> {
    const [event] = await db
      .update(calendarEvents)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(calendarEvents.id, id))
      .returning();
    return event;
  }

  async getTodaysEvents(): Promise<CalendarEvent[]> {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return await db
      .select()
      .from(calendarEvents)
      .where(and(
        sql`DATE(${calendarEvents.startDate}) = CURRENT_DATE`
      ))
      .orderBy(calendarEvents.startDate);
  }

  // Student incidents
  async createStudentIncident(incident: InsertStudentIncident): Promise<StudentIncident> {
    const [newIncident] = await db.insert(studentIncidents).values(incident).returning();
    return newIncident;
  }

  async getAllStudentIncidents(): Promise<StudentIncident[]> {
    return await db
      .select()
      .from(studentIncidents)
      .orderBy(desc(studentIncidents.createdAt));
  }

  async getIncidentsByStudent(studentName: string): Promise<StudentIncident[]> {
    return await db
      .select()
      .from(studentIncidents)
      .where(eq(studentIncidents.studentName, studentName))
      .orderBy(desc(studentIncidents.createdAt));
  }

  async updateStudentIncident(id: string, updateData: Partial<InsertStudentIncident>): Promise<StudentIncident> {
    const [incident] = await db
      .update(studentIncidents)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(studentIncidents.id, id))
      .returning();
    return incident;
  }

  // Dashboard statistics
  async getDashboardStats(): Promise<any> {
    const [teacherCount] = await db
      .select({ count: count() })
      .from(users)
      .where(eq(users.role, 'teacher'));

    const [pendingActivitiesCount] = await db
      .select({ count: count() })
      .from(activities)
      .where(eq(activities.status, 'pending'));

    const lowStockItems = await this.getLowStockItems();
    const todaysEvents = await this.getTodaysEvents();

    return {
      teachers: teacherCount.count,
      pendingActivities: pendingActivitiesCount.count,
      lowStock: lowStockItems.length,
      todayEvents: todaysEvents.length,
    };
  }
}

export const storage = new DatabaseStorage();
